﻿
namespace Cyotek.GhostScript
{
  public enum PdfTrimMode
  {
    PaperSize,
    TrimBox,
    CropBox
  }
}
