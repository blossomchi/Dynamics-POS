﻿
namespace Cyotek.GhostScript
{
  public enum GridFitMode
  {
    None,
    SkipPatentedInstructions,
    Topological,
    Mixed
  }
}
