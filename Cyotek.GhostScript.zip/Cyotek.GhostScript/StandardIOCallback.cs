﻿using System;

namespace Cyotek.GhostScript
{
  public delegate int StdioCallBack(IntPtr handle, IntPtr strptr, int len);
}
