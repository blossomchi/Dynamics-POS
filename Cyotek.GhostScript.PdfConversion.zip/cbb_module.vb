Namespace CBB

Public Module cbb_module
    Public searchString As String = "one"
    Public imgpropdir As String = "images/property/"

End Module

End Namespace
